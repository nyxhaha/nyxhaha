FiveM Application Data/Plugins/
put the d3d10.dll file in the plugins Folder

open menu with Ins/Einf

by nyx